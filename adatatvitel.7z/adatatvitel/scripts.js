
function szamol() {
    const adatMennyiseg = document.getElementById("adatmennyiseg").value,
        adatMennyiseginput = document.getElementById("adatmennyiseginput").value,
        atviteliMennyiseg = document.getElementById("atvitelimennyiseg").value,
        atviteliSebesseg = document.getElementById("atvitelisebesseg").value,
        atviteliIdo = document.getElementById("atviteliido");

    if (adatMennyiseg == atviteliSebesseg) {
        const eredmeny = parseFloat(adatMennyiseginput) / parseFloat(atviteliMennyiseg);
        atviteliIdo.textContent = new Date(eredmeny * 1000).toISOString().slice(11, 19);
    }
    else if (adatMennyiseg == "TB" && atviteliSebesseg == "GB") {
        const eredmeny = parseFloat(adatMennyiseginput) / (parseFloat(atviteliMennyiseg)/1000)
        atviteliIdo.textContent = new Date(eredmeny * 1000).toISOString().slice(11, 19);
    }
    else if (adatMennyiseg == "TB" && atviteliSebesseg == "MB") {
        const eredmeny = parseFloat(adatMennyiseginput) / (parseFloat(atviteliMennyiseg)/1000000);
        atviteliIdo.textContent = new Date(eredmeny * 1000).toISOString().slice(11, 19);
    }
    else if (adatMennyiseg == "TB" && atviteliSebesseg == "KB") {
        const eredmeny = parseFloat(adatMennyiseginput) / (parseFloat(atviteliMennyiseg)/1000000000);
        atviteliIdo.textContent = new Date(eredmeny * 1000).toISOString().slice(11, 19);
    }
    else if (adatMennyiseg == "GB" && atviteliSebesseg == "MB") {
        const eredmeny = parseFloat(adatMennyiseginput) / (parseFloat(atviteliMennyiseg)/1000);
        atviteliIdo.textContent = new Date(eredmeny * 1000).toISOString().slice(11, 19);
    }
    else if (adatMennyiseg == "GB" && atviteliSebesseg == "KB") {
        const eredmeny = parseFloat(adatMennyiseginput) / (parseFloat(atviteliMennyiseg)/1000000);
        atviteliIdo.textContent = new Date(eredmeny * 1000).toISOString().slice(11, 19);
    }
    else if (adatMennyiseg == "MB" && atviteliSebesseg == "GB") {
        const eredmeny = parseFloat(adatMennyiseginput) / (parseFloat(atviteliMennyiseg)*1000);
        atviteliIdo.textContent = new Date(eredmeny * 1000).toISOString().slice(11, 19);
    }
    else if (adatMennyiseg == "MB" && atviteliSebesseg == "KB") {
        const eredmeny = parseFloat(adatMennyiseginput) / (parseFloat(atviteliMennyiseg)/1000);
        atviteliIdo.textContent = new Date(eredmeny * 1000).toISOString().slice(11, 19);
    }
    else if (adatMennyiseg == "KB" && atviteliSebesseg == "GB") {
        const eredmeny = parseFloat(adatMennyiseginput) / (parseFloat(atviteliMennyiseg)*1000000);
        atviteliIdo.textContent = new Date(eredmeny * 1000).toISOString().slice(11, 19);
    }
    else if (adatMennyiseg == "KB" && atviteliSebesseg == "MB") {
        const eredmeny = parseFloat(adatMennyiseginput) / (parseFloat(atviteliMennyiseg)*1000);
        atviteliIdo.textContent = new Date(eredmeny * 1000).toISOString().slice(11, 19);
    }
}

function slider() {
    const atviteliMennyiseg = document.getElementById("atvitelimennyiseg").value,
    atMennySpan = document.getElementById("atMennySpan");

    atMennySpan.textContent = atviteliMennyiseg; 
}